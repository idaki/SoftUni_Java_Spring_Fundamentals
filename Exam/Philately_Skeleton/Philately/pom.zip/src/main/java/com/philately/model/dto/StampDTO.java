package com.philately.model.dto;

public class StampDTO {
}
