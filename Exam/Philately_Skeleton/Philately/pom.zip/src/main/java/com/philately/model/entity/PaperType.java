package com.philately.model.entity;

public enum PaperType {
    WOVE_PAPER,
    LAID_PAPER,
    GRANITE_PAPER;

}
